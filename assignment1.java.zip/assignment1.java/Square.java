// Q2: Program to calculate area and perimeter of a square
class Square {
    public static void main(String[] args) {
        double side = 4.0; // fixed side length
        double area = side * side;
        double perimeter = 4 * side;

        System.out.println("Area of Square: " + area);
        System.out.println("Perimeter of Square: " + perimeter);
    }
}