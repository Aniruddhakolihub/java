// Q4: Class Complex with init method
class Complex {
    private double real;
    private double imag;

    public void init(double real, double imag) {
        this.real = real;
        this.imag = imag;
    }

    public void display() {
        System.out.println("Complex Number: " + real + " + " + imag + "i");
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Please provide real and imaginary parts as command line arguments.");
            return;
        }

        try {
            double real = Double.parseDouble(args[0]);
            double imag = Double.parseDouble(args[1]);

            Complex complex = new Complex();
            complex.init(real, imag);
            complex.display();
        } catch (NumberFormatException e) {
            System.out.println("Error: Arguments must be valid double values.");
        }
    }
}
