// Q1: Program to calculate area and circumference of a circle
class Circle {
    public static void main(String[] args) {
        double radius = 5.0; // fixed radius
        double area = Math.PI * radius * radius;
        double circumference = 2 * Math.PI * radius;

        System.out.println("Area of Circle: " + area);
        System.out.println("Circumference of Circle: " + circumference);
    }
}