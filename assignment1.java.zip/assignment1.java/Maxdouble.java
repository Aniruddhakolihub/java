// Q3: Program to find maximum of two double values
import java.util.Scanner;

class MaxDouble {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first double value: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter second double value: ");
        double num2 = scanner.nextDouble();

        double max = Math.max(num1, num2);
        System.out.println("Maximum value: " + max);
    }
}