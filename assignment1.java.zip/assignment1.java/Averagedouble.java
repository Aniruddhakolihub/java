// Q5: Program to check data type and calculate average
import java.util.Scanner;

class AverageDouble {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first value: ");
        String input1 = scanner.next();
        System.out.print("Enter second value: ");
        String input2 = scanner.next();

        try {
            double num1 = Double.parseDouble(input1);
            double num2 = Double.parseDouble(input2);
            double average = (num1 + num2) / 2;

            System.out.println("Average: " + average);
        } catch (NumberFormatException e) {
            System.out.println("Error: Both inputs must be double values.");
        }
    }
}